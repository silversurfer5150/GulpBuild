// A $( document ).ready() block.
$( document ).ready(function() {
    $("h1").fadeIn(1500);
	$(".box").fadeIn(3500);
	$(".box h2").fadeIn(4500, sortable());
});